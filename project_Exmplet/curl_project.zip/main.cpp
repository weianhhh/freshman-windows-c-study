#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

#define URL_LENGTH 256

size_t write_data(void* ptr, size_t size, size_t nmemb, FILE* stream) {
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}

int main(int argc, char** argv) {
    if (argc != 2) { // ֻ����һ�������в���������Ƶ���ӵ�ַ
        fprintf(stderr, "Usage: %s <video-link>", argv[0]);
        exit(EXIT_FAILURE);
    }

    char url[URL_LENGTH];
    strncpy(url, argv[1], URL_LENGTH);

    CURL* curl_handle;
    CURLcode res;

    FILE* video_file;
    video_file = fopen("D:\\video.mp4", "wb");
    if (!video_file) {
        fprintf(stderr, "Cannot create file");
        exit(EXIT_FAILURE);
    }

    curl_handle = curl_easy_init();
    curl_easy_setopt(curl_handle, CURLOPT_URL, url);
    curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_data);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, video_file);
    res = curl_easy_perform(curl_handle);
    if (res != CURLE_OK) {
        fprintf(stderr, "curl_easy_perform() failed: %s", curl_easy_strerror(res));
    }

    curl_easy_cleanup(curl_handle);
    fclose(video_file);

    printf("Video downloaded successfully.");

        return 0;
}
